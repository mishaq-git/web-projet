# Code Citations

## License: unknown

https://github.com/freyhill/freyhill.github.io/tree/93ff85076768e97a60b21dd49bebd8a681a5a912/example/currying/index.html

```
.html -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"
```

## License: unknown

https://github.com/talissoncosta/talissoncosta.github.io/tree/84fb74635ad7b69c472102a41cfa3a39af933c9c/frontend-mentor/advice-generator-app-main/index.html

```
UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="icon" type="image/png" sizes="32x32" href="./assets
```

## License: unknown

https://github.com/Alaa-OmarAlshobaki/ruler/tree/d90edacb76f704b8f9e15e923fdd9c76439e7deb/.history/index_20200227133344.html

```
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel=
```

## License: unknown

https://github.com/olppaemi/launch-countdown-timer/tree/e80b7d1daa9cbd770c56ebc543de663059464370/public/index.html

```
"en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="icon" type="image/png
```

## License: MIT

https://github.com/anjali697/chatbotwebsitesample/tree/1922a3234c3fa28409ff26f74e6475fded751507/portfolio/index.html

```
->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link
```
